#Config File
apiKey = 'kE0Ev6f915YaP0qwNapXTuu0w'
apiSecret = 'omsPcxU5e6XMll7nX3sQOYEkvrrqG9DVzcmQOBBZ4nATNqeqPi'

oauthKey = '3126662205-rSkU4AHMAOlnKKeHK2jky0AzQzrs1mFa4BmgNX3'
oauthSecret = '53g2YanPTBNHTXjO1gFPBPx2PHWRge6OFHSAO9KsB9EiV'

